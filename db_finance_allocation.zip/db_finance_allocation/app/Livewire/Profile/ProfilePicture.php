<?php

namespace App\Livewire\Profile;

use Livewire\Component;

class ProfilePicture extends Component
{
    public function render()
    {
        return view('livewire.profile.profile-picture');
    }
}
